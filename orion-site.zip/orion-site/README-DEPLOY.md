# ORION — פריסת אב־טיפוס ל־Vercel

## האפשרות המהירה ביותר: חיבור ל־GitHub

1. צור Repository חדש ב־GitHub, למשל `orion-osint-dashboard`.
2. הורד/העתק אליו את הקובץ `index.html`.
3. היכנס ל־Vercel ובחר **Add New → Project**.
4. בחר **Import Git Repository** ובחר את ה־Repository.
5. בהגדרות הפרויקט:
   - Framework Preset: `Other`
   - Build Command: להשאיר ריק
   - Output Directory: `.` או להשאיר ברירת מחדל
   - Install Command: להשאיר ריק
6. לחץ **Deploy**.

## האפשרות ללא GitHub

1. היכנס ל־Vercel.
2. בחר **Add New → Project**.
3. השתמש ב־**Deploy without Git** או העלה את תיקיית הפרויקט דרך Vercel CLI.
4. ודא שבתיקייה נמצא הקובץ `index.html` בשורש.

## דרך Vercel CLI

```bash
npm i -g vercel
cd לתיקיית-הפרויקט
vercel login
vercel
```

ענה על השאלות של Vercel. לפריסה לייצור:

```bash
vercel --prod
```

## בדיקה לאחר הפריסה

- פתח את כתובת ה־Vercel שקיבלת.
- בדוק שהעברית מיושרת מימין לשמאל.
- בדוק את החיפוש והסינון בדיווחים.
- בדוק את תפריט הניווט ואת כפתור הרענון.
- בדוק תצוגה בנייד.

## שלב הבא לאחר שהאתר באוויר

1. חיבור דומיין, אם יש.
2. הוספת Google OAuth עם כתובת אימייל מורשית יחידה.
3. יצירת Backend ו־Database.
4. חיבור מקורות Telegram ציבוריים, RSS ו־APIs רשמיים בלבד.
5. הוספת קליטת אירועים בזמן אמת.
6. הוספת אימות, הצלבה, התראות וייצוא דוחות.

הקובץ הנוכחי הוא אב־טיפוס סטטי עם נתוני דוגמה. אין בו עדיין מפתחות API או חיבור למקורות אמיתיים.
