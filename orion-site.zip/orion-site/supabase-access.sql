-- שלב הבא: טבלת הרשאות. מריצים ב-Supabase SQL Editor.
create table if not exists public.access_requests (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);
alter table public.access_requests enable row level security;
-- בהמשך נוסיף policies בטוחות: משתמש רואה רק את הבקשה שלו; האדמין מנהל דרך server-side function.
